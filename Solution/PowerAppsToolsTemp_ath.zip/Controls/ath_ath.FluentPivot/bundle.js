/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./FluentPivot/PivotControl.tsx":
/*!**************************************!*\
  !*** ./FluentPivot/PivotControl.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ReactPivotControl: () => (/* binding */ ReactPivotControl)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\n\nvar ReactPivotControl = props => {\n  var {\n    items,\n    onTabClick,\n    selectedAlias,\n    rememberSelected\n  } = props;\n  var [activeAlias, setActiveAlias] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(selectedAlias);\n  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {\n    if (!rememberSelected && selectedAlias !== activeAlias) {\n      setActiveAlias(selectedAlias);\n    }\n  }, [selectedAlias, rememberSelected, activeAlias]);\n  // Function to handle tab click\n  var handleLinkClick = item => {\n    if (item) {\n      var alias = item.props.itemKey;\n      if (alias) {\n        setActiveAlias(alias);\n        onTabClick(alias);\n      }\n    }\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Pivot, {\n    onLinkClick: handleLinkClick,\n    selectedKey: activeAlias || undefined\n  }, items.map((item, index) => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.PivotItem, {\n    headerText: item.name,\n    key: index,\n    itemKey: item.alias\n  }))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./FluentPivot/PivotControl.tsx?");

/***/ }),

/***/ "./FluentPivot/index.ts":
/*!******************************!*\
  !*** ./FluentPivot/index.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   FluentPivot: () => (/* binding */ FluentPivot)\n/* harmony export */ });\n/* harmony import */ var _PivotControl__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PivotControl */ \"./FluentPivot/PivotControl.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass FluentPivot {\n  constructor() {\n    this._selectedAlias = null;\n  }\n  /**\n   * Called when the control is initialized\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    return this.renderControl(context);\n  }\n  /**\n   * Update view when data changes\n   */\n  updateView(context) {\n    console.log(\"Update view PCF\");\n    var itemsJson = context.parameters.tabs.raw || '[]';\n    var items = JSON.parse(itemsJson);\n    var rememberSelected = context.parameters.rememberSelected.raw;\n    console.log(rememberSelected);\n    if (!rememberSelected) {\n      // eslint-disable-next-line @typescript-eslint/no-explicit-any\n      var defaultTab = items.find(item => item.isDefault) || null;\n      if (defaultTab) {\n        this._selectedAlias = defaultTab.alias;\n      } else {\n        this._selectedAlias = null; // Reset alias if no default tab\n      }\n    }\n    return this.renderControl(context);\n  }\n  renderControl(context) {\n    var itemsJson = context.parameters.tabs.raw || '[]';\n    var items = JSON.parse(itemsJson);\n    var rememberSelected = context.parameters.rememberSelected.raw;\n    // eslint-disable-next-line @typescript-eslint/no-explicit-any\n    var defaultTab = items.find(item => item.isDefault) || null;\n    if (defaultTab) {\n      this._selectedAlias = defaultTab.alias;\n    }\n    var props = {\n      items: items,\n      onTabClick: this.onTabClick.bind(this),\n      selectedAlias: this._selectedAlias,\n      rememberSelected: rememberSelected\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_PivotControl__WEBPACK_IMPORTED_MODULE_0__.ReactPivotControl, props);\n  }\n  onTabClick(alias) {\n    this._selectedAlias = alias;\n    this._notifyOutputChanged();\n  }\n  /**\n   * Called when the PCF control needs to output data\n   */\n  getOutputs() {\n    var _a;\n    return {\n      selectedTab: (_a = this._selectedAlias) !== null && _a !== void 0 ? _a : undefined\n    };\n  }\n  /**\n   * Clean up when the control is removed\n   */\n  destroy() {}\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./FluentPivot/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./FluentPivot/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ath.FluentPivot', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FluentPivot);
} else {
	var ath = ath || {};
	ath.FluentPivot = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FluentPivot;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}